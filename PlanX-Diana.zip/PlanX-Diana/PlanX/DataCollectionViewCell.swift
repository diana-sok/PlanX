//
//  DataCollectionViewCell.swift
//  H2OT
//
//  Created by admin on 7/12/19.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit

class DataCollectionViewCell: UICollectionViewCell {
    
    // variables
    @IBOutlet weak var DateLabel: UILabel!
    
    @IBOutlet weak var DateView: UIView!
    
}
