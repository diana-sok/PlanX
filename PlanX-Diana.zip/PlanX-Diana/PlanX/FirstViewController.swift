//
//  FirstViewController.swift
//  PlanX
//
//  Created by Diana Sok on 6/26/19.
//  Copyright © 2019 H2OT. All rights reserved.
//

import UIKit
//specify that ill be using classes in firebase librarues
import FirebaseDatabase

class FirstViewController: UIViewController {
//correspinds to home unused boars, delte later?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
     
        //let ref = Database.database().reference()
      //  ref.child("someid/name").setValue("Mike") //write example
//        ref.child("someid/name").observeSingleEvent(of: .value) { (snapshot) in
//            let name = snapshot.value as? [String: Any]
//            print(name)
       // }
        
    }


}

