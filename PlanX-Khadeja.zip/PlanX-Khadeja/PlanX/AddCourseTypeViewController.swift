//
//  AddCourseTypeViewController.swift
//  PlanX
//
//  Created by admin on 7/26/19.
//  Copyright © 2019 H2OT. All rights reserved.
//

import UIKit

class AddCourseTypeViewController: NSObject {

}
