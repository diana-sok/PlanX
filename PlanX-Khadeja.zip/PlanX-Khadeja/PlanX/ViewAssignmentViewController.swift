//
//  ViewAssignmentViewController.swift
//  PlanX CoursesTab
//
//  Created by admin on 7/14/19.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase

class ViewAssignmentViewController: UIViewController {
    
    var ref:DatabaseReference?
    
    let assignName = assignmentList[myAssignmentIndex]
    let courseName = courseList[myCourseIndex]

    @IBOutlet weak var assignmentName: UILabel!
    @IBOutlet weak var assignmentType: UILabel!
    @IBOutlet weak var dueDate: UILabel!
    @IBOutlet weak var score: UILabel!
    @IBOutlet weak var details: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set Firebase reference
        let ref = Database.database().reference()
        let userID = ref.child(Auth.auth().currentUser!.uid) //Get user
        

        // Sets the assignment's name
        assignmentName.text = "   " + assignName
        
        // Sets the assignment's type label
        
        // Sets the assignment's due date label
        
        // Sets the assignment's percentage out of 100
        
        // Sets the assignment's status (incomplete/complete)
        
        // Sets the details
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
        
    }
}
