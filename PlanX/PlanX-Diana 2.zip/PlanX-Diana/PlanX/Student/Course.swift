//
//  Course.swift
//  PlanX
//
//  Created by Diana Sok on 7/15/19.
//  Copyright © 2019 H2OT. All rights reserved.
//

import Foundation

class Course {
    private var courseDivisions:[CourseDivision]
    
    // Constructors
    init() {
        courseDivisions = []
    }
    
    init(courseDivisions:[CourseDivision]) {
        self.courseDivisions = courseDivisions
    }
    
}
