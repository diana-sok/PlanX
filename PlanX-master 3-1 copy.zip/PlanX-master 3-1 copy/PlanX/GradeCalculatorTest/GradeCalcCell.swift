//
//  GradeCalcCell.swift
//  PlanX
//
//  Created by Diana Sok on 8/4/19.
//  Copyright © 2019 H2OT. All rights reserved.
//

import UIKit

class GradeCalcCell: UITableViewCell, UITextFieldDelegate {

    // variables
    @IBOutlet weak var assignName: UILabel!
    @IBOutlet weak var scoreEntry: UITextField!
    @IBOutlet weak var weightageEntry: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        scoreEntry.delegate = self
        weightageEntry.delegate = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    // user can only enter a number in text field
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let allowedCharacters = "+1234567890"
        let aallowedCharSet = CharacterSet(charactersIn: allowedCharacters)
        let charEnteredSet = CharacterSet(charactersIn: string)
        return aallowedCharSet.isSuperset(of: charEnteredSet)
    }
    
    

}
