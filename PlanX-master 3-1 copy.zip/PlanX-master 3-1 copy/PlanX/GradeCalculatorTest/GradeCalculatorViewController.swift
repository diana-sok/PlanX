//
//  GradeCalculatorViewController.swift
//  PlanX
//
//  Created by Diana Sok on 8/4/19.
//  Copyright © 2019 H2OT. All rights reserved.
//

import UIKit
import FirebaseDatabase
import FirebaseAuth

var assignList = [String]()
var assignmentCount = 0

protocol GradeCalcButtonActivated {
    //boss's command --> what it can tell intern to do
    func gradeCalcButtonActivated(score: Double)
}
class GradeCalculatorViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var grade:Double = 0
    let ref = Database.database().reference()
    var gradeDelegate: GradeCalcButtonActivated?

    
    @IBOutlet weak var gradeCalcTable: UITableView!
    
    @IBAction func gradeCalculation(_ sender: UIButton) {
        grade = 0
        var i = IndexPath()
        let cell = gradeCalcTable.dequeueReusableCell(withIdentifier: "AssignmentCells", for: i) as! GradeCalcCell
        
        var list = [GradeCalcCell]()
        let sectionCount = gradeCalcTable.numberOfSections
        for section in 0 ..< sectionCount {
            let rowCount = gradeCalcTable.numberOfRows(inSection: section)
            //var list = [GradeCalcCell]()
            
            for row in 0 ..< rowCount {
                let cell = gradeCalcTable.cellForRow(at: NSIndexPath(row: row, section: section) as IndexPath) as! GradeCalcCell
                list.append(cell)
            }
        }
        
        //var grade:Double = 0
        
        for cellRow in list {
            let a:Double? = Double(cellRow.scoreEntry.text!)
            let b:Double? = Double(cellRow.weightageEntry.text!)
            
            if let aa = a {
                if let bb = b {
                    //
                    let convert = aa * (bb/100)
                    grade += convert
                }
            }
           
        }
        print(grade)
        //let vc = GradeResultsViewController(nibName: "GradeResultsViewController", bundle: nil)
       // vc.result.text = "hello"
        
        //navigationController?.pushViewController(vc, animated: true)
        
       performSegue(withIdentifier: "getResults", sender: self)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        gradeCalcTable.dataSource = self
        gradeCalcTable.delegate = self
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        let courseName = listOfCourses[courseCount]
        let assignmentType =  assignType[assignCount]
        // var assignmentTypeName = assignmentType
        
        // Clear the string array
        assignList = [String]()
        
        // Set Firebase reference
        //let ref = Database.database().reference()
        let userID = ref.child(Auth.auth().currentUser!.uid) //Get user
        
        // Get the data from Firebase & listen for new data
        userID.child("Courses").child(courseName).child(assignmentType).observeSingleEvent(of: .value) { (snapshot) in
            for child in snapshot.children {
                if let childSnapshot = child as? DataSnapshot {
                    // Turn value into a string
                    let value = childSnapshot.key as? String
                    
                    // Add assignments to list
                    if let actualValue = value{
                        if (actualValue != "Percentage")
                        {
                            assignList.append(actualValue)
                            self.gradeCalcTable.reloadData()
                        }
                    }
                }
            }
        }
    }
    
    // MARK: - Table view data source
    
    /*override func numberOfSections(in tableView: UITableView) -> Int {
     // #warning Incomplete implementation, return the number of sections
     return 0
     }*/
    
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return assignList.count
    }
    
    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AssignmentCells", for: indexPath) as! GradeCalcCell
        
        // Configure the cell...
        //cell.textLabel?.text = assignList[indexPath.row]
        // set the name of the assignment
       // cell.assignName.text = assignList[indexPath.row]
        cell.assignName.text = assignList[indexPath.row]
        // set the score of the assignment
        
        
        return cell
    }
    
    //Refreshes the list
    override func viewDidAppear(_ animated: Bool) {
        gradeCalcTable.reloadData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //if segue.identifier == "getResults" {
        //var vc : GradeResultsViewController = segue.destination as! GradeResultsViewController
            //self.gradeDelegate = vc
        
        let vc = segue.destination as! GradeResultsViewController
        vc.test = "\(grade)"
        vc.grade = grade
            
//            if let mygrade = grade {
//                print(mygrade)
//                vc.gradeResult.text = "yay"
//                //vc.gradeResult.text = g
//            } else {
//                vc.gradeResult.text = "oops"
//            }
            
            
            //gradeDelegate?.gradeCalcButtonActivated(score: self.grade)
            //vc.selectionDelegate?.singleDayTapped(assignments:    )
        }
    }
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

//}
