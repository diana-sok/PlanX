//
//  GradeResultsViewController.swift
//  PlanX
//
//  Created by Roshini  Malempati  on 7/31/19.
//  Copyright © 2019 H2OT. All rights reserved.
//

import UIKit

class GradeResultsViewController: UIViewController {
   
    
    @IBOutlet weak var result: UILabel!
    @IBOutlet weak var future: UILabel!
    @IBOutlet weak var courseLabel: UILabel!
    
    @IBOutlet weak var weightOfFinalTextField: UITextField!
    @IBOutlet weak var desiredGrade: UITextField!
    
    var test = ""
    var course = ""
    var grade = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        result.text = test
        // Do any additional setup after loading the view.
    }
    
    @IBAction func calculateFinalScoreNeededTapped(_ sender: UIButton) {
        
        /*
         // Final grade calculation portion
         // add 1 text field - finalGradeWeightage
         // change the label under final question to a text view - desired grade
         // add a text view underneath that one asking for finalWeitage - finalWeitage
         // add a label underneath that one that shows the finalGradeNeeded
         */
        var currentGrade = grade // change to double as we did for the other strings - this is the same calculation u got for the first part in results
        //var desiredGradeValue = desiredGrade.text // chnage to double as we did for other strings
        //var finalWeightage = weightOfFinalTextField.text // change to double
        
        let finalWeightageValue:Double? = Double(weightOfFinalTextField.text!)
        let desiredGradeValue:Double? = Double(desiredGrade.text!)
        if let finalWeightageBB = finalWeightageValue {
            if let desiredGradeAA = desiredGradeValue {
                var finalGradeNeeded = (100 * desiredGradeAA - (100 - finalWeightageBB) * currentGrade) / finalWeightageBB;
                
                if (finalGradeNeeded >= 90) {
                    future.text = "\(finalGradeNeeded)";
                    
                } else if (finalGradeNeeded >= 80 && finalGradeNeeded < 90) {
                    future.text = "\(finalGradeNeeded)"
                    
                } else if (finalGradeNeeded < 80) {
                    future.text = "\(finalGradeNeeded)"
                }
                
            }
        }
        
        

    }
    

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
