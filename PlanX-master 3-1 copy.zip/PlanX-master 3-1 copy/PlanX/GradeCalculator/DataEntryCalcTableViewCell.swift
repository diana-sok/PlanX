//
//  DataEntryCalcTableViewCell.swift
//  PlanX
//
//  Created by Roshini  Malempati  on 8/3/19.
//  Copyright © 2019 H2OT. All rights reserved.
//

import UIKit

class DataEntryCalcTableViewCell: UITableViewCell, UITextFieldDelegate {

    // variables
    @IBOutlet weak var scoreEntry: UITextField!
    @IBOutlet weak var totalLbl: UILabel!
    @IBOutlet weak var assignName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        scoreEntry.delegate = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
        
        
    }
    
    // user can only enter a number in text field 
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let allowedCharacters = "+1234567890"
        let aallowedCharSet = CharacterSet(charactersIn: allowedCharacters)
        let charEnteredSet = CharacterSet(charactersIn: string)
        return aallowedCharSet.isSuperset(of: charEnteredSet)
    }

}
