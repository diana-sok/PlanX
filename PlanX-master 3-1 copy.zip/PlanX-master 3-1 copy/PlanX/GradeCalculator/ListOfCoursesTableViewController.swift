//
//  ListOfCoursesTableViewController.swift
//  PlanX
//
//  Created by Roshini  Malempati  on 7/31/19.
//  Copyright © 2019 H2OT. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase

// global variables
var listOfCourses = [String]()
var courseCount = 0

class ListOfCoursesTableViewController: UITableViewController {
    
    @IBOutlet var courseTableView: UITableView!
    
    let ref = Database.database().reference()
    
    //Number of cells to display
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listOfCourses.count
        //return(list.count)
    }
    
    //Displays each element
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "CourseCell")
        //cell.textLabel?.text = list[indexPath.row]
        cell.textLabel?.text = listOfCourses[indexPath.row]
        return(cell)
    }
    
    //Refreshes the list
    override func viewDidAppear(_ animated: Bool) {
        courseTableView.reloadData()
    }
    
    //Clickable table items
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        courseCount = indexPath.row
        performSegue(withIdentifier: "CourseSelectedSegue", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        listOfCourses = [String]()
        
        // Set Firebase reference
        //let ref = Database.database().reference()
        let userID = ref.child(Auth.auth().currentUser!.uid) //Get user
        
        // Get the data from Firebase & listen for new data
        userID.child("Courses").observeSingleEvent(of: .value) { (snapshot) in
            for child in snapshot.children {
                if let childSnapshot = child as? DataSnapshot {
                    // Turn value into a string
                    let value = childSnapshot.key as? String
                    
                    // Add courses to list
                    if let actualValue = value{
                        listOfCourses.append(actualValue)
                        self.courseTableView.reloadData()
                    }
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
